#!"C:\Users\zhank\AppData\Local\Programs\Python\Python37\python.exe"

print ('Content-Type: text/html')
print ('Set-Cookie: name="runoob";expires=Wed, 28 Aug 2019 18:30:00 GMT')
print ()
print ("""
<html>
  <head>
    <meta charset="utf-8">
    <title>菜鸟教程(runoob.com)</title>
  </head>
    <body>
        <h1>Cookie set OK!</h1>
    </body>
</html>
""")