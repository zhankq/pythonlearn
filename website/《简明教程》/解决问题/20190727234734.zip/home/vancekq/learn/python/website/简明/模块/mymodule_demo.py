import mymodule
mymodule.say_hi()
print('Version', mymodule.__version__)

print(dir(mymodule))
