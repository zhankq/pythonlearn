lst = [1,2,3,4]
it = iter(lst)
for x in it:
    print(x,",")
