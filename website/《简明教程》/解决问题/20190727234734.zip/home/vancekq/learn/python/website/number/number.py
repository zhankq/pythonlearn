x='a'
print(int(x))

