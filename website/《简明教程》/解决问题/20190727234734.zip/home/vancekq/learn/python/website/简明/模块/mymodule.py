def say_hi():
    '''
    good
    :return:
    '''
    print('Hi, this is mymodule speaking.')

__version__ = '0.1'
